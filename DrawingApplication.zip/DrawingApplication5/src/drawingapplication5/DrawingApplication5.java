/*
 * @author neelsakhrani
 * 
 * Assignment 5 - 2D Drawing Application
 */

//import packages
package drawingapplication5;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class DrawingApplication5 {

    public static void main(String[] args)
    {
        DrawingApplicationFrame frame = new DrawingApplicationFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(650,500);
        frame.setVisible(true);
    }
    
}
